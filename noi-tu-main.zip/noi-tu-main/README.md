<h1 align="center">Nối Từ</h1>
<p align="center">Trò chơi nối từ tiếng Việt</p>
<p align="center"><img width="25%" src="logo.svg"></p>
<p align="center">
  <a href="https://github.com/NNBnh/brainalias/blob/main/LICENSE"><img src="https://img.shields.io/github/license/NNBnh/noi-tu?labelColor=585858&color=5890F8&style=for-the-badge" alt="License: GPL-3.0"></a>
  <a href="https://gist.github.com/NNBnh/9ef453aba3efce26046e0d3119dab5a7#development-completed"><img src="https://img.shields.io/badge/development-completed-%235890F8.svg?labelColor=585858&style=for-the-badge&logoColor=FFFFFF" alt="Development completed"></a>
</p>

## 💡 About

**Nối từ** là trò chơi trí tuệ. Người chơi sẽ lần lượt đưa ra một từ có hai âm tiết bắt đầu bằng chữ cuối cùng trong từ lúc trước đưa ra. Người chơi không được phép sử dụng từ đã từng được dùng trong ván chơi, trò chơi kết thúc khi người chơi không nối được từ tiếp theo.

## 💌 Credits

Special thanks to:
- [**Từ điển mở tiếng Việt**](https://github.com/undertheseanlp/dictionary) by [Under The Sea](https://github.com/undertheseanlp)

<br><br><br><br>

---

> <h1 align="center">Made with ❤️ by <a href="https://github.com/NNBnh"><i>NNB</i></a></h1>
>
> <p align="center"><a href="https://www.buymeacoffee.com/nnbnh"><img src="https://img.shields.io/badge/buy_me_a_coffee%20-%23FFC387.svg?logo=buy-me-a-coffee&logoColor=333333&style=for-the-badge" alt="Buy Me a Coffee"></a></p>
